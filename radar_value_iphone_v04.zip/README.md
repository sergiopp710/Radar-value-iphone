# Radar Value iPhone · versión 0.4 · 0 €

Aplicación web progresiva para iPhone que recibe snapshots de un escáner programado en **GitHub Actions**, publicados en **GitHub Pages**. No necesitas dejar el móvil ni tu ordenador encendidos. **No es tiempo real ni una app de App Store**. De forma predeterminada el análisis se ejecuta una vez al día (si GitHub ejecuta el cron). Los resultados solo incluyen 1X2 y totales de goles disponibles y respaldados por histórico suficiente; el resto de mercados aún no están integrados automáticamente.

## Publicar gratis — sin escribir código

1. Crea una cuenta gratuita en https://github.com/ y un repositorio nuevo **público** (por ejemplo `radar-value-iphone`). GitHub Pages con plan Free permite repositorios públicos. **No subas tu clave en archivos**.
2. Descomprime el ZIP y sube su contenido a la raíz del repositorio, incluyendo la carpeta oculta `.github/workflows/`. La interfaz web de GitHub puede omitir archivos ocultos al seleccionarlos; verifica que aparezca `.github/workflows/radar.yml` en el repositorio.
3. Solicita una clave gratuita en https://the-odds-api.com/ y en GitHub entra en `Settings → Secrets and variables → Actions → New repository secret`. Nombre **THE_ODDS_API_KEY**, valor: tu clave (nunca en un commit).
4. Ve a `Settings → Pages → Build and deployment → Source: GitHub Actions`.
5. En `Actions → Radar Value iPhone (gratuito) → Run workflow` ejecuta manualmente la primera actualización. Espera a que se complete y revisa el estado o errores en Actions.
6. Abre la URL de Pages del repositorio en **Safari del iPhone**, normalmente `https://USUARIO.github.io/radar-value-iphone/` (la URL exacta aparece en Pages).
7. En Safari: Compartir → Añadir a pantalla de inicio → activar **Abrir como app web** → Añadir.

En adelante GitHub ejecutará el trabajo diariamente alrededor de **07:17 UTC**; los horarios de GitHub Actions no son garantizados ni exactos. En repositorios públicos inactivos, GitHub puede desactivar las tareas programadas después de un tiempo. El botón ↻ de la app vuelve a descargar los últimos datos publicados; no genera un nuevo escaneo ni consume créditos.

### Límites y privacidad

- Plan gratuito The Odds API: 500 créditos al mes (consumo depende de consultas, mercados y regiones). La configuración por defecto consulta solo tres ligas, una vez al día; verifica el uso y ajusta si hace falta.
- Los datos y señales publicados en GitHub Pages son **públicos**. La clave no se publica porque se inyecta como Secret durante la construcción. No añadas datos personales ni credenciales al contenido del sitio. GitHub Actions y Pages están sujetos a sus límites y condiciones.
- **No hay notificaciones push** en esta versión. Hay que abrir la app para revisar las publicaciones nuevas. Sin servidor dedicado, esta arquitectura ofrece actualizaciones por lotes, no vigilancia continua segundo a segundo.
- Si no hay clave o cuotas reales, no se inventan pronósticos. Cuando los datos se quedan antiguos (>36h) se muestra aviso. Los encuentros que ya han empezado se ocultan.
- Los modelos son experimentales y no están validados fuera de muestra. El EV es una estimación, no una garantía de ganancias. Si hay cambios de cuotas, resultados o alineaciones, pueden quedar obsoletas.

### Ejecutar pruebas y previsualizar en ordenador

```bash
python -m unittest discover -s tests -v
python -m http.server 8000 --directory web
```

Abre `http://localhost:8000`. Sin análisis previo el panel muestra el estado sin configurar y 0 señales.

### Cómo añadir otras ligas

Edita `RADAR_LEAGUES` en `.github/workflows/radar.yml` usando códigos permitidos en `radar/auto.py` (`LEAGUES`) y respeta `max_sports=3`. No se puede garantizar cobertura mundial gratuita con un único proveedor.
