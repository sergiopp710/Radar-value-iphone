"""Build published snapshots; no example predictions and no API credentials in site."""
import json, os, csv
from pathlib import Path
from datetime import datetime, timezone
from radar.auto import run_auto
ROOT=Path(__file__).resolve().parent
WEB=ROOT/'web'
DATA=ROOT/'data'
WEB.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)
now=datetime.now(timezone.utc).isoformat()
status={'status':'sin_configurar','generated_at':None,'interval_hours':24,'message':'Sin clave gratuita. No se publican predicciones ficticias.'}
rows=[]
try:
    if not os.getenv('THE_ODDS_API_KEY'):
        raise RuntimeError('Falta THE_ODDS_API_KEY en los secrets de GitHub Actions.')
    sports=[v.strip() for v in os.getenv('RADAR_LEAGUES','soccer_spain_la_liga,soccer_epl,soccer_italy_serie_a').split(',') if v.strip()]
    # Protect free API quota: at most three leagues in a single daily scan.
    report=run_auto(output=str(DATA/'automatico.html'),sports=sports,max_sports=3)
    fp=DATA/'radar_automatico.csv'
    if fp.exists():
        with fp.open(encoding='utf-8-sig',newline='') as f:
            for r in csv.DictReader(f):
                try:
                    p=float(r['model_probability']);price=float(r['book_odds']);ev=float(r['ev_pct']);ec=float(r['ev_conservador_pct'])
                    if not (0<p<1 and price>1):continue
                    rows.append({'fixture_id':r['fixture_id'],'date':r['date'],'league':r['league'],'home':r['home'],'away':r['away'],'market':r['market'],'category':r['category'],'bookmaker':r['bookmaker'],'probability':round(100*p,2),'fair_odds':float(r['fair_odds']),'book_odds':price,'ev':ev,'ev_conservative':ec,'candidate':r['candidato'].lower()=='true','sample_home':int(r['sample_home']),'sample_away':int(r['sample_away']),'captured_at':r['captured_at']})
                except (KeyError,TypeError,ValueError):continue
    rows.sort(key=lambda x:(not x['candidate'],-x['ev_conservative']))
    status={'status':'actualizado' if report.get('market_prices',0)>0 else 'sin_datos','generated_at':now,'interval_hours':24,'message':f'Consulta terminada. {len(rows)} comparaciones; señales experimentales no validadas.' if report.get('market_prices',0)>0 else 'No se encontraron cuotas/partidos compatibles. Revisa el informe y la cobertura.','sports':report.get('sports',[]),'matched_fixtures':report.get('upcoming_matched',0),'data_warning':'No garantiza beneficio. Las cuotas pueden caducar.'}
except Exception as e:
    status={'status':'error','generated_at':now,'interval_hours':24,'message':str(e)[:240], 'data_warning':'No se han publicado pronósticos simulados.'}
(WEB/'status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
(WEB/'signals.json').write_text(json.dumps({'signals':rows,'count':len(rows),'notice':'Estimaciones exploratorias no validadas. No confirman errores de la casa.'},ensure_ascii=False),encoding='utf-8')
print('Estado:',status['status'],'comparaciones:',len(rows))
