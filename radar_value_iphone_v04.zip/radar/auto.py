"""Pipeline automático, gratuito, sin scraping. Datos actuales SOLO con clave gratis Odds API.
No presume que una coincidencia de nombres es cierta: registra las rechazadas.
"""
import json, os, re, unicodedata, difflib
from pathlib import Path
from datetime import datetime, timezone, timedelta
from collections import defaultdict
from .sources import get_json
from .core import write_csv, read_csv, evaluate
from .report import render

LEAGUES={
 'soccer_spain_la_liga':'es.1', 'soccer_epl':'en.1',
 'soccer_germany_bundesliga':'de.1', 'soccer_italy_serie_a':'it.1',
 'soccer_france_ligue_one':'fr.1', 'soccer_netherlands_eredivisie':'nl.1',
 'soccer_portugal_primeira_liga':'pt.1', 'soccer_usa_mls':'us.1',
}
# Only supported mappings are considered: unsupported fixtures are reported, not guessed.
ALIASES={
 'atletico madrid':'club atletico de madrid', 'real betis':'real betis balompie',
 'barcelona':'fc barcelona', 'athletic bilbao':'athletic club',
 'celta vigo':'rc celta de vigo', 'espanyol':'rcd espanyol de barcelona',
 'rayo vallecano':'rayo vallecano de madrid', 'real sociedad':'real sociedad de futbol',
 'alaves':'deportivo alaves', 'mallorca':'rcd mallorca', 'real oviedo':'real oviedo',
 'bayern munich':'fc bayern munchen', 'psg':'paris saint germain'
}
IGNORE={'fc','cf','sc','afc','ac','rc','rcd','club','de','the','football','futbol','futebol','calcio'}
def normalize(name):
 s=unicodedata.normalize('NFKD',name.casefold())
 s=''.join(c for c in s if not unicodedata.combining(c))
 s=re.sub(r'[^a-z0-9 ]',' ',s);s=' '.join(s.split())
 s=ALIASES.get(s,s)
 return ' '.join(t for t in s.split() if t not in IGNORE)
def similarity(a,b):
 x,y=normalize(a),normalize(b)
 if x==y:return 1.
 ax=set(x.split());by=set(y.split())
 if not ax or not by:return 0
 overlap=len(ax&by)/max(len(ax),len(by))
 return max(difflib.SequenceMatcher(None,x,y).ratio()*.85,overlap)
def parse_time(value):
 if not value:return None
 try:return datetime.fromisoformat(value.replace('Z','+00:00')).replace(tzinfo=timezone.utc) if 'T' not in value else datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(timezone.utc)
 except ValueError:return None

def fetch_odds(key, sport, region='eu'):
 import urllib.parse
 query=urllib.parse.urlencode({'apiKey':key,'regions':region,'markets':'h2h,totals','oddsFormat':'decimal','dateFormat':'iso'})
 return get_json('https://api.the-odds-api.com/v4/sports/'+urllib.parse.quote(sport,safe='')+'/odds/?'+query)

def fetch_history(code, seasons, cache_dir):
 cache_dir=Path(cache_dir);cache_dir.mkdir(parents=True,exist_ok=True)
 all_rows=[]; sources=[]
 for season in seasons:
  path=cache_dir/f'{code}_{season}.json'
  url=f'https://raw.githubusercontent.com/openfootball/football.json/master/{season}/{code}.json'
  if path.exists():
   obj=json.loads(path.read_text(encoding='utf-8'))
  else:
   try:
    obj=get_json(url);path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
   except Exception as e:
    sources.append({'url':url,'status':'error','error':str(e)[:140]});continue
  sources.append({'url':url,'status':'ok','matches':len(obj.get('matches',[]))})
  for m in obj.get('matches',[]):
   score=m.get('score') or {}; ft=score.get('ft') if isinstance(score,dict) else score
   if not (isinstance(ft,list) and len(ft)==2 and all(isinstance(x,int) for x in ft)):continue
   h,a=m.get('team1'),m.get('team2')
   if h and a and m.get('date'):
    row={'date':m['date'],'league':code,'home':h,'away':a,'home_goals':ft[0],'away_goals':ft[1]}
    ht=score.get('ht') if isinstance(score,dict) else None
    if isinstance(ht,list) and len(ht)==2 and all(isinstance(x,int) for x in ht):row.update(home_ht_goals=ht[0],away_ht_goals=ht[1])
    all_rows.append(row)
 return all_rows,sources

def run_auto(output='informes/automatico.html', key=None, sports=None, seasons=None, max_sports=3, min_ev=3., region='eu', now=None):
 key=key or os.getenv('THE_ODDS_API_KEY')
 if not key:raise ValueError('No hay clave gratuita THE_ODDS_API_KEY. Puedes obtenerla en the-odds-api.com. Sin ella no se pueden obtener automáticamente las cuotas actuales.')
 now=now or datetime.now(timezone.utc)
 seasons=seasons or [f'{now.year-1}-{str(now.year)[-2:]}',f'{now.year}-{str(now.year+1)[-2:]}']
 sports=sports or list(LEAGUES)
 unsupported=[s for s in sports if s not in LEAGUES]
 if unsupported:raise ValueError('No hay mapeo de histórico gratuito verificado para: '+', '.join(unsupported))
 sports=sports[:max_sports]
 base=Path(output).parent;base.mkdir(parents=True,exist_ok=True)
 matches=[];fixtures=[];odds=[]; audit=[];sources=[]
 for sport in sports:
  code=LEAGUES[sport]
  history,history_log=fetch_history(code,seasons,base/'cache')
  matches.extend(history);sources.extend(history_log)
  try:games=fetch_odds(key,sport,region)
  except Exception as e:
   audit.append({'sport':sport,'status':'odds_error','reason':str(e)[:180]});continue
  teams=set(r['home'] for r in history)|set(r['away'] for r in history)
  for g in games:
   dt=parse_time(g.get('commence_time'))
   if not dt or dt<=now or dt>now+timedelta(days=14):continue # never live
   home,away=g.get('home_team',''),g.get('away_team','')
   pairs=[]
   for requested in [home,away]:
    matches_ranked=sorted(((similarity(requested,t),t) for t in teams),reverse=True)
    top=matches_ranked[:2]
    if len(top)<1 or top[0][0]<.83 or (len(top)>1 and top[0][0]-top[1][0]<.09):break
    pairs.append(top[0][1])
   if len(pairs)!=2 or pairs[0]==pairs[1]:
    audit.append({'sport':sport,'match':home+' - '+away,'status':'unmatched','reason':'Equipo no vinculado con certeza al histórico gratuito'});continue
   fid='oddsapi:'+str(g.get('id'))
   fixtures.append({'fixture_id':fid,'date':g['commence_time'],'league':code,'home':pairs[0],'away':pairs[1]})
   count=0
   for bookmaker in g.get('bookmakers',[]):
    for market in bookmaker.get('markets',[]):
     for o in market.get('outcomes',[]):
      name=o.get('name');key_market=market.get('key');m=None
      if key_market=='h2h':m='X' if name=='Draw' else '1' if name==home else '2' if name==away else None
      elif key_market=='totals' and name in ('Over','Under') and o.get('point') is not None:
       line=float(o['point'])
       if line%1==.5:m=f'goals_{name}_{line:g}'
      if m:
       odds.append({'fixture_id':fid,'category':'goals','market':m,'bookmaker':bookmaker.get('title',bookmaker.get('key','')),'odds':o.get('price'),'captured_at':market.get('last_update') or bookmaker.get('last_update','')})
       count+=1
   audit.append({'sport':sport,'match':home+' - '+away,'status':'matched','reason':f'{pairs[0]} / {pairs[1]}; cuotas: {count}'})
 cols_matches=['date','league','home','away','home_goals','away_goals','home_ht_goals','away_ht_goals']
 write_csv(base/'historico_auto.csv',matches,cols_matches)
 write_csv(base/'proximos_auto.csv',fixtures,['fixture_id','date','league','home','away'])
 write_csv(base/'cuotas_auto.csv',odds,['fixture_id','category','market','bookmaker','odds','captured_at'])
 write_csv(base/'auditoria_fuentes.csv',audit,['sport','match','status','reason'])
 signals,coverage=evaluate(fixtures,matches,odds)
 # Conservative preliminary check: EV must stay positive with probability 3pp lower.
 # Not statistically derived; visible heuristic, not a confidence bound.
 for row in signals:
  p=row['model_probability'];price=row['book_odds'];row['ev_conservador_pct']=round(100*((p-.03)*price-1),2)
  row['candidato']=row['ev_pct']>=min_ev and row['ev_conservador_pct']>0 and row['sample_home']>=15 and row['sample_away']>=15
  row['data_warning']='NO VALIDADO históricamente; sensibilidad -3 puntos; verificar cuotas y fechas'
 signals.sort(key=lambda r:(not r['candidato'],-r['ev_conservador_pct']))
 render(signals,coverage,output)
 write_csv(base/'radar_automatico.csv',signals,fields=['fixture_id','date','league','home','away','category','market','bookmaker','model_probability','fair_odds','book_odds','ev_pct','ev_conservador_pct','candidato','sample_home','sample_away','model_quality','captured_at','data_warning','model_expected_home','model_expected_away'])
 report={'generated_at':now.isoformat(),'mode':'REAL - fuentes gratuitas, si APIs responden','matches_historic':len(matches),'upcoming_matched':len(fixtures),'market_prices':len(odds),'comparisons':len(signals),'candidates_unvalidated':sum(x['candidato'] for x in signals),'sports':sports,'sources':sources,'audited':len(audit),'warning':'Candidato no equivale a apuesta rentable; ningún modelo ha sido validado fuera de muestra.'}
 (base/'estado_automatico.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 return report
