"""Permitted public sources; no scraping bookmaker sites."""
import json, os, urllib.request, urllib.parse
from datetime import datetime, timezone
from .core import write_csv

def get_json(url, headers=None):
    request=urllib.request.Request(url,headers={'User-Agent':'RadarFutbolGratis/0.1 (open-data research)',**(headers or {})})
    with urllib.request.urlopen(request,timeout=20) as r:return json.load(r)

def openfootball(season, league_code, destination):
    # E.g. season=2025-26 league_code=es.1, en.1, de.1, it.1
    if not season.replace('-','').isdigit() or not league_code.replace('.','').isalnum():raise ValueError('Season/league invalid')
    url=f'https://raw.githubusercontent.com/openfootball/football.json/master/{season}/{league_code}.json'
    obj=get_json(url)
    matches=[]; fixtures=[]
    name=obj.get('name',league_code)
    for n,m in enumerate(obj.get('matches',[])):
        home=m.get('team1','');away=m.get('team2','');day=m.get('date','')
        if not(home and away and day):continue
        fid=f'openfootball:{season}:{league_code}:{n}'
        score=m.get('score') or {}
        ft=score.get('ft') or []
        if len(ft)==2 and all(isinstance(x,(int,float)) for x in ft):
            matches.append({'date':day,'league':name,'home':home,'away':away,'home_goals':ft[0],'away_goals':ft[1]})
        else:fixtures.append({'fixture_id':fid,'date':day,'league':name,'home':home,'away':away})
    write_csv(destination+'/matches_openfootball.csv', matches, ['date','league','home','away','home_goals','away_goals'])
    write_csv(destination+'/fixtures_openfootball.csv', fixtures, ['fixture_id','date','league','home','away'])
    return {'source':url,'league':name,'played':len(matches),'upcoming':len(fixtures)}

def odds_api(sport, api_key, destination, region='eu'):
    # Free tier, credits consumed; only user-initiated request.
    if not api_key:raise ValueError('THE_ODDS_API_KEY required')
    query=urllib.parse.urlencode({'regions':region,'markets':'h2h,totals','oddsFormat':'decimal','apiKey':api_key})
    obj=get_json(f'https://api.the-odds-api.com/v4/sports/{urllib.parse.quote(sport,safe="")}/odds?{query}')
    fixtures=[]; odds=[];now=datetime.now(timezone.utc).isoformat()
    for game in obj:
        fid='oddsapi:'+str(game['id']); home=game['home_team']; away=game['away_team']
        fixtures.append({'fixture_id':fid,'date':game['commence_time'],'league':game.get('sport_title',sport),'home':home,'away':away})
        for book in game.get('bookmakers',[]):
            for market in book.get('markets',[]):
                key=market.get('key')
                for outcome in market.get('outcomes',[]):
                    label=outcome.get('name','');market_name=None
                    if key=='h2h':market_name= 'X' if label=='Draw' else '1' if label==home else '2' if label==away else None
                    elif key=='totals':
                        pt=outcome.get('point')
                        if pt is not None and label in ('Over','Under'):market_name=f'goals_{label}_{float(pt):g}'
                    if market_name:
                        odds.append({'fixture_id':fid,'category':'goals','market':market_name,'bookmaker':book.get('title',book.get('key','')),
                         'odds':outcome.get('price'),'captured_at':book.get('last_update',now)})
    write_csv(destination+'/fixtures_oddsapi.csv', fixtures,['fixture_id','date','league','home','away'])
    write_csv(destination+'/odds_oddsapi.csv',odds,['fixture_id','category','market','bookmaker','odds','captured_at'])
    return {'fixtures':len(fixtures),'odds':len(odds),'sport':sport}
