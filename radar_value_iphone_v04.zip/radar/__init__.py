"""Radar prepartido de fútbol: modelos verificables y fuentes gratuitas."""
