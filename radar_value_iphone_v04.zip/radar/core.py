import csv, math, json, statistics
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

MIN_MATCHES=8

def read_csv(path):
    with open(path, encoding='utf-8-sig', newline='') as f: return list(csv.DictReader(f))

def write_csv(path, rows, fields=None):
    rows=list(rows); fields=fields or (list(rows[0]) if rows else [])
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with open(path,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader();w.writerows(rows)

def numeric(v):
    try: return float(str(v).replace(',','.')) if str(v).strip() else None
    except (ValueError,TypeError): return None

def poisson_distribution(lam, cap=13):
    # Tail put into final bucket, so distribution sums to 1.
    p=[math.exp(-lam)]
    for k in range(1,cap):p.append(p[-1]*lam/k)
    p.append(max(0,1-sum(p)))
    return p

def team_strengths(matches, fixture, metric='goals'):
    """Only matches strictly before fixture; per-league; shrink toward league mean."""
    date=str(fixture['date'])[:10]; league=fixture['league']
    suffix={'goals':('home_goals','away_goals'),'corners':('home_corners','away_corners'),
            'cards':('home_cards','away_cards'),'shots':('home_shots','away_shots'),
            'shots_on_target':('home_sot','away_sot'),'half_goals':('home_ht_goals','away_ht_goals')}[metric]
    played=[]
    for m in matches:
        a,b=numeric(m.get(suffix[0])),numeric(m.get(suffix[1]))
        if m.get('league')==league and str(m.get('date',''))[:10]<date and a is not None and b is not None and a>=0 and b>=0:
            played.append((m['home'],m['away'],a,b))
    if len(played)<20:return None
    league_home=sum(r[2] for r in played)/len(played)
    league_away=sum(r[3] for r in played)/len(played)
    if min(league_home,league_away)<0.05:return None
    home,away=fixture['home'],fixture['away']
    home_own=[r for r in played if r[0]==home]
    away_own=[r for r in played if r[1]==away]
    # Need 8 observations in each team's corresponding setting.
    if len(home_own)<MIN_MATCHES or len(away_own)<MIN_MATCHES:return None
    prior=7.0
    h_for=(sum(r[2] for r in home_own)+prior*league_home)/(len(home_own)+prior)
    h_against=(sum(r[3] for r in home_own)+prior*league_away)/(len(home_own)+prior)
    a_for=(sum(r[3] for r in away_own)+prior*league_away)/(len(away_own)+prior)
    a_against=(sum(r[2] for r in away_own)+prior*league_home)/(len(away_own)+prior)
    lh=max(.03, min(7.5, league_home*(h_for/league_home)*(a_against/league_home)))
    la=max(.03, min(7.5, league_away*(a_for/league_away)*(h_against/league_away)))
    quality='media' if min(len(home_own),len(away_own))<15 else 'alta_muestra'
    return (lh,la, quality, len(home_own),len(away_own))

def market_probabilities(lh,la,category='goals'):
    a=poisson_distribution(lh); b=poisson_distribution(la)
    events={}
    def put(k,p,push=0):
        if p>0 and p<1.00000001:events[k]=(min(1,max(0,p)),push)
    total=sum((i+j)*x*y for i,x in enumerate(a) for j,y in enumerate(b))
    if category=='goals':
        put('1',sum(x*y for i,x in enumerate(a) for j,y in enumerate(b) if i>j))
        put('X',sum(x*y for i,x in enumerate(a) for j,y in enumerate(b) if i==j))
        put('2',sum(x*y for i,x in enumerate(a) for j,y in enumerate(b) if i<j))
        for name,condition in [('1X',lambda i,j:i>=j),('X2',lambda i,j:i<=j),('12',lambda i,j:i!=j),('BTTS_Si',lambda i,j:i>0 and j>0),('BTTS_No',lambda i,j:i==0 or j==0)]:
            put(name,sum(x*y for i,x in enumerate(a) for j,y in enumerate(b) if condition(i,j)))
        for i in range(6):
            for j in range(6):put(f'Exacto_{i}-{j}',a[i]*b[j])
        for side in ('1','2'):
            for line in (-2.5,-1.5,-.5,.5,1.5,2.5):
                p=sum(x*y for i,x in enumerate(a) for j,y in enumerate(b) if ((i-j if side=='1' else j-i)+line)>0)
                put(f'Handicap_{side}_{line:+g}',p)
    if category in ('goals','corners','cards','shots','shots_on_target','half_goals'):
        levels=range(0,7) if category in ('goals','half_goals') else (range(3,17) if category=='corners' else range(1,11) if category=='cards' else range(3,25) if category=='shots' else range(0,13))
        for threshold in levels:
            p=sum(x*y for i,x in enumerate(a) for j,y in enumerate(b) if i+j>threshold)
            put(f'{category}_Over_{threshold}.5',p)
            put(f'{category}_Under_{threshold}.5',1-p)
        for label,arr in [('Local',a),('Visitante',b)]:
            for t in range(0,5 if category in ('goals','half_goals') else 9):
                p=sum(x for k,x in enumerate(arr) if k>t)
                put(f'{category}_{label}_Over_{t}.5',p)
    return events

def evaluate(fixtures,matches,odds):
    # Match by explicit fixture_id, not fuzzy name matching.
    by_id=defaultdict(list)
    for o in odds:by_id[str(o.get('fixture_id',''))].append(o)
    signals=[]; coverage=[]
    now=datetime.now(timezone.utc).isoformat()
    for f in fixtures:
        f_id=str(f['fixture_id']); pools={}; notes=[]
        for cat in ('goals','half_goals','corners','cards','shots','shots_on_target'):
            strengths=team_strengths(matches,f,cat)
            if strengths:
                lh,la,q,nh,na=strengths
                pools.update({(cat,k):(p,q,nh,na,lh,la) for k,(p,push) in market_probabilities(lh,la,cat).items()})
            else: notes.append(cat)
        coverage.append({'fixture_id':f_id,'league':f['league'],'home':f['home'],'away':f['away'],'unavailable':','.join(notes), 'modeled_categories':len(set(k[0] for k in pools))})
        for o in by_id[f_id]:
            # Unsupported or player markets remain explicitly unmodeled, never estimated from guesses.
            cat=o.get('category','goals'); market=o.get('market','')
            if (cat,market) not in pools:continue
            p,q,nh,na,lh,la=pools[(cat,market)]
            price=numeric(o.get('odds'))
            if not price or price<=1:continue
            # freshness and pre-match constraints; odds may be stale: warn not discard unless in-play.
            ts=o.get('captured_at','').strip(); start=f.get('date','').strip()
            if ts and start and ts[:10]>start[:10]:continue
            ev=p*price-1
            signals.append({'fixture_id':f_id,'date':f['date'],'league':f['league'],'home':f['home'],'away':f['away'],
              'category':cat,'market':market,'bookmaker':o.get('bookmaker',''), 'model_probability':round(p,5),
              'fair_odds':round(1/p,3),'book_odds':round(price,3),'ev_pct':round(100*ev,2),
              'sample_home':nh,'sample_away':na,'model_quality':q,'captured_at':ts,
              'data_warning':'No validado fuera de muestra; comprobar actualidad y condiciones',
              'model_expected_home':round(lh,2),'model_expected_away':round(la,2)})
    signals.sort(key=lambda s:s['ev_pct'],reverse=True)
    return signals,coverage
