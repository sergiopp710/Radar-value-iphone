import argparse,os,json
from pathlib import Path
from .core import read_csv,write_csv,evaluate
from .sources import openfootball,odds_api
from .report import render

def main():
    ap=argparse.ArgumentParser(description='Radar mundial de fútbol prepartido - sin APIs de pago')
    sub=ap.add_subparsers(dest='command',required=True)
    run=sub.add_parser('analizar');run.add_argument('--partidos',required=True);run.add_argument('--proximos',required=True);run.add_argument('--cuotas',required=True);run.add_argument('--salida',default='informes/radar.html')
    imp=sub.add_parser('openfootball');imp.add_argument('--temporada',required=True);imp.add_argument('--liga',required=True);imp.add_argument('--destino',default='datos')
    odd=sub.add_parser('oddsapi');odd.add_argument('--deporte',default='soccer_spain_la_liga');odd.add_argument('--region',default='eu');odd.add_argument('--destino',default='datos')
    auto=sub.add_parser("automatico",help="Obtiene histórico y cuotas actuales con fuentes gratuitas, cruza y clasifica")
    auto.add_argument("--ligas",default="soccer_spain_la_liga,soccer_epl,soccer_italy_serie_a")
    auto.add_argument("--max-ligas",type=int,default=3)
    auto.add_argument("--ev-min",type=float,default=3.0)
    auto.add_argument("--salida",default="informes/automatico.html")
    auto.add_argument("--region",default="eu")
    args=ap.parse_args()
    if args.command=='automatico':
        from .auto import run_auto
        print(json.dumps(run_auto(output=args.salida,sports=[x.strip() for x in args.ligas.split(',') if x.strip()],max_sports=args.max_ligas,min_ev=args.ev_min,region=args.region),ensure_ascii=False,indent=2))
    elif args.command=='openfootball':print(json.dumps(openfootball(args.temporada,args.liga,args.destino),ensure_ascii=False,indent=2))
    elif args.command=='oddsapi':print(json.dumps(odds_api(args.deporte,os.getenv('THE_ODDS_API_KEY'),args.destino,args.region),ensure_ascii=False,indent=2))
    else:
        sig,cov=evaluate(read_csv(args.proximos),read_csv(args.partidos),read_csv(args.cuotas))
        render(sig,cov,args.salida)
        write_csv(str(Path(args.salida).with_suffix('.csv')),sig,fields=['fixture_id','date','league','home','away','category','market','bookmaker','model_probability','fair_odds','book_odds','ev_pct','sample_home','sample_away','model_quality','captured_at','data_warning','model_expected_home','model_expected_away'])
        write_csv(str(Path(args.salida).with_name('cobertura.csv')),cov,fields=['fixture_id','league','home','away','unavailable','modeled_categories'])
        print(f'Informe: {args.salida}; cuotas analizadas: {len(sig)}; partidos: {len(cov)}')
if __name__=='__main__':main()
