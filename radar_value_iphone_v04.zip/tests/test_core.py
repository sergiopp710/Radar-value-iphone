import unittest
from radar.core import poisson_distribution,market_probabilities,team_strengths,evaluate,read_csv
class ModelTests(unittest.TestCase):
 def test_distribution(self):
  for rate in [.1,1,2,6]:self.assertAlmostEqual(sum(poisson_distribution(rate)),1,places=8)
 def test_1x2(self):
  m=market_probabilities(1.3,1.5)
  self.assertAlmostEqual(sum(m[k][0] for k in ['1','X','2']),1,places=7)
  self.assertAlmostEqual(m['BTTS_Si'][0]+m['BTTS_No'][0],1,places=7)
  self.assertLess(m['goals_Over_3.5'][0],m['goals_Over_2.5'][0])
 def test_no_leakage(self):
  f={'date':'2026-01-01','league':'x','home':'a','away':'b'}
  rows=[{'date':'2026-01-02','league':'x','home':'a','away':'b','home_goals':'5','away_goals':'1'}]*40
  self.assertIsNone(team_strengths(rows,f))
 def test_demo(self):
  s,c=evaluate(read_csv('datos/proximos_demo.csv'),read_csv('datos/partidos_demo.csv'),read_csv('datos/cuotas_demo.csv'))
  self.assertEqual(len(c),4);self.assertTrue(len(s)>20)
  self.assertTrue(all(x['fixture_id'].startswith('DEMO-') for x in s))
if __name__=='__main__':unittest.main()
