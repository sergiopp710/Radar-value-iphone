import unittest
from unittest.mock import patch
from tempfile import TemporaryDirectory
from pathlib import Path
from datetime import datetime,timezone,timedelta
from radar.auto import run_auto,normalize,similarity
class AutoTests(unittest.TestCase):
 def test_normalize(self):
  self.assertEqual(normalize('FC Barcelona'),normalize('Barcelona'))
  self.assertGreater(similarity('Atlético Madrid','Club Atlético de Madrid'),.99)
 def test_no_key(self):
  with patch.dict('os.environ',{},clear=True):
   with self.assertRaisesRegex(ValueError,'clave gratuita'):
    run_auto()
 def test_real_mode_pipeline_mock(self):
  d=datetime.now(timezone.utc)+timedelta(days=1)
  dt=d.isoformat().replace('+00:00','Z')
  rows=[]
  for j in range(80):
   rows.append({'date':(d-timedelta(days=j+2)).strftime('%Y-%m-%d'),'league':'es.1','home':'FC Barcelona' if j%2 else 'Real Madrid CF', 'away':'Real Madrid CF' if j%2 else 'FC Barcelona','home_goals':2,'away_goals':1})
  fixture={'id':'test123','commence_time':dt,'home_team':'Barcelona','away_team':'Real Madrid CF',
    'bookmakers':[{'title':'Casa ficticia','markets':[{'key':'h2h','last_update':datetime.now(timezone.utc).isoformat(),'outcomes':[{'name':'Barcelona','price':2.0},{'name':'Draw','price':3.5},{'name':'Real Madrid CF','price':4.2}]}]}]}
  with TemporaryDirectory() as td:
   with patch('radar.auto.fetch_history',return_value=(rows,[])), patch('radar.auto.fetch_odds',return_value=[fixture]):
    result=run_auto(output=str(Path(td)/'auto.html'),key='fake',sports=['soccer_spain_la_liga'],max_sports=1)
   self.assertEqual(result['upcoming_matched'],1)
   self.assertGreater(result['comparisons'],0)
   self.assertTrue((Path(td)/'radar_automatico.csv').exists())
   self.assertIn('candidato', (Path(td)/'auto.html').read_text())
if __name__=='__main__':unittest.main()
