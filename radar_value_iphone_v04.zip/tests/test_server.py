import tempfile
import unittest
from pathlib import Path
from server import Engine

class MobileTests(unittest.TestCase):
    def test_engine_without_saved_state(self):
        with tempfile.TemporaryDirectory() as p:
            import server
            old=server.STATE
            try:
                server.STATE=Path(p)/'status.json'
                e=Engine(interval_hours=24)
                self.assertEqual(e.state['status'],'sin_configurar')
                self.assertEqual(e.interval,86400)
            finally:server.STATE=old

    def test_mobile_assets_exist(self):
        root=Path(__file__).resolve().parents[1]/'web'
        for name in ('index.html','app.js','styles.css','manifest.json','sw.js','icon.svg'):
            self.assertTrue((root/name).is_file())
