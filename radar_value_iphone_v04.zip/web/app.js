'use strict';
const $ = id => document.getElementById(id);
let signals=[], lastStatus={};
const escapeHtml = t => String(t??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const timeStr = iso => { if(!iso)return 'No disponible';let d=new Date(iso);return isNaN(d)?'No disponible':d.toLocaleString('es-ES',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});};
async function fetchJson(endpoint, opts){const r=await fetch(endpoint,{cache:'no-store',...opts});const j=await r.json();if(!r.ok)throw new Error(j.message||'Error al consultar datos');return j;}
function draw(){
 let threshold=Number($('ev').value);$('ev-label').textContent=threshold+'%';
 let rows=(lastStatus.generated_at && (Date.now()-Date.parse(lastStatus.generated_at)>36*3600000))?[]:signals.filter(x=>(!$('candidate').checked||x.candidate)&&(!x.market||!$('market').value||x.market===$('market').value)&&x.ev>=threshold && new Date(x.date)>new Date());
 const s=$('sort').value;
 rows.sort((a,b)=>s==='date'?new Date(a.date)-new Date(b.date):s==='ev'?b.ev-a.ev:b.ev_conservative-a.ev_conservative);
 $('count').textContent=rows.length;
 if(!rows.length){$('cards').innerHTML='<div class="empty">No hay candidatos que cumplan los filtros. Puede que falten cuotas, histórico suficiente o cobertura de mercado. No se inventan pronósticos.</div>';return;}
 $('cards').innerHTML=rows.slice(0,120).map(x=>`<article class="item"><div class="item-top"><span class="tag">${escapeHtml(x.league)} · ${timeStr(x.date)}</span><span class="ev">${x.ev>=0?'+':''}${Number(x.ev).toFixed(1)}% EV</span></div><h3>${escapeHtml(x.home)} — ${escapeHtml(x.away)}</h3><div class="market-name">${escapeHtml(x.market)}</div><div class="numbers"><div><small>MI PROB.</small><b>${Number(x.probability).toFixed(1)}%</b></div><div><small>CUOTA JUSTA</small><b>${Number(x.fair_odds).toFixed(2)}</b></div><div><small>CUOTA CASA</small><b>${Number(x.book_odds).toFixed(2)}</b></div></div><div class="foot"><span>${escapeHtml(x.bookmaker)} · ${timeStr(x.captured_at)}</span><span class="badge ${x.candidate?'':'maybe'}">${x.candidate?'Candidato no validado':'Revisar'}</span><span>EV prudente ${Number(x.ev_conservative).toFixed(1)}%</span></div></article>`).join('');
}
async function load(){try{
 const [s,r]=await Promise.all([fetchJson('./status.json'),fetchJson('./signals.json')]);lastStatus=s;signals=r.signals||[];
 const el=$('status');el.className='status '+(s.status==='actualizado'?'ok':s.status==='error'?'error':'');
 el.innerHTML=`<div><span class="status-dot"></span><b>${escapeHtml(s.status==='actualizado'?'Datos del último análisis':s.status==='error'?'Revisar actualización':'Esperando configuración')}</b><p>${escapeHtml(s.message||'')} · Actualización programada en GitHub (no en el iPhone).</p></div>`;
 $('total').textContent=signals.length.toLocaleString('es-ES');$('found').textContent=signals.filter(x=>x.candidate).length; $('updated').textContent=timeStr(s.generated_at);if(s.generated_at){const age=(Date.now()-Date.parse(s.generated_at))/3600000;if(age>36){$('status').className='status error';$('status').insertAdjacentHTML('beforeend','<p>⚠ Datos desactualizados ('+Math.round(age)+' h). No considerar las cuotas vigentes.</p>');}}
 const selected=$('market').value;const markets=[...new Set(signals.map(x=>x.market))].sort();$('market').innerHTML='<option value="">Todos los mercados</option>'+markets.map(m=>`<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');$('market').value=markets.includes(selected)?selected:'';
 draw();
 }catch(e){$('status').className='status error';$('status').innerHTML=`<div><span class="status-dot"></span><b>Sin conexión al servidor</b><p>${escapeHtml(e.message)}</p></div>`;}}
for(const id of ['market','sort','ev','candidate'])$(id).addEventListener('input',draw);
$('refresh').onclick=async()=>{await load();};
$('info').href='#disclaimer';document.querySelector('.disclaimer').id='disclaimer';
load();setInterval(load,60*1000);
if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
