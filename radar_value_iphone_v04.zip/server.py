"""Radar PWA: standard-library HTTP server + scheduled data collection.
Deploy on a continuously running machine to get continuous scans.
"""
import argparse
import csv
import json
import os
import threading
import time
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
from radar.auto import run_auto, LEAGUES

ROOT = Path(__file__).resolve().parent
WEB = ROOT / 'web'
DATA = ROOT / 'data'
STATE = DATA / 'status.json'
SIGNALS = DATA / 'radar_automatico.csv'
LOCK = threading.Lock()
MIN_MANUAL_INTERVAL = 20 * 60  # prevent unintentional free credit exhaustion

class Engine:
    def __init__(self, interval_hours=24, leagues=None, max_leagues=3, region='eu'):
        self.interval = max(1, float(interval_hours)) * 3600
        self.leagues = leagues or list(LEAGUES)[:3]
        self.max_leagues = max(1, int(max_leagues))
        self.region = region
        self.last_attempt = 0
        self.next_due = 0
        self.busy = False
        DATA.mkdir(parents=True, exist_ok=True)
        self.state = self._load_state()

    def _load_state(self):
        try: return json.loads(STATE.read_text(encoding='utf-8'))
        except (OSError, ValueError): return {'status':'sin_configurar','message':'Aún no hay un análisis con datos reales.'}

    def _save_state(self, new_state):
        self.state = new_state
        STATE.write_text(json.dumps(new_state,ensure_ascii=False,indent=2),encoding='utf-8')

    def refresh(self, force=False):
        with LOCK:
            if self.busy: return False, 'Ya hay un análisis en curso.'
            if force and time.time()-self.last_attempt < MIN_MANUAL_INTERVAL:
                return False, 'Límite de seguridad: espera al menos 20 minutos entre consultas manuales.'
            self.busy = True
        threading.Thread(target=self._scan,daemon=True).start()
        return True, 'Actualización iniciada.'

    def _scan(self):
        self.last_attempt = time.time()
        old=self.state
        self._save_state({**old,'status':'analizando','message':'Consultando fuentes gratuitas y calculando cuotas...','started_at':datetime.now(timezone.utc).isoformat()})
        try:
            if not os.getenv('THE_ODDS_API_KEY'):
                raise ValueError('Falta THE_ODDS_API_KEY (clave gratuita). No se generan pronósticos ficticios.')
            result=run_auto(output=str(DATA/'automatico.html'),sports=self.leagues,max_sports=self.max_leagues,region=self.region)
            self._save_state({'status':'actualizado','message':'Análisis terminado. Modelos exploratorios sin validación fuera de muestra.',**result,'next_scan_at':datetime.fromtimestamp(time.time()+self.interval,timezone.utc).isoformat()})
        except Exception as exc:
            self._save_state({**{k:v for k,v in old.items() if k not in ('message','status')}, 'status':'error','message':str(exc)[:300],'last_error_at':datetime.now(timezone.utc).isoformat()})
        finally:
            self.next_due=time.time()+self.interval
            with LOCK: self.busy=False

    def loop(self):
        # Schedule the first run immediately; background scanning continues while this server runs.
        while True:
            if not self.busy and time.time()>=self.next_due:
                self.refresh()
            time.sleep(10)

ENGINE = None

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(WEB),**kwargs)
    def reply(self,status,payload):
        data=json.dumps(payload,ensure_ascii=False).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/api/status':
            self.reply(200,{**ENGINE.state,'refreshing':ENGINE.busy,'configured':bool(os.getenv('THE_ODDS_API_KEY')),'interval_hours':round(ENGINE.interval/3600,2),'leagues':ENGINE.leagues[:ENGINE.max_leagues], 'supported_live_markets':['1X2','Más/menos goles']});return
        if path=='/api/signals':
            if not SIGNALS.is_file():self.reply(200,{'signals':[],'count':0});return
            with SIGNALS.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
            results=[]
            for r in rows:
                try:
                    p=float(r['model_probability']); price=float(r['book_odds']);ev=float(r['ev_pct']);evc=float(r['ev_conservador_pct'])
                except (ValueError,KeyError):continue
                if not (0<p<1 and price>1):continue
                # One best available bookmaker per fixture + exact market; keep names to identify it.
                results.append({'fixture_id':r['fixture_id'],'date':r['date'],'league':r['league'],'home':r['home'],'away':r['away'], 'market':r['market'],'category':r['category'],'bookmaker':r['bookmaker'],'probability':round(p*100,2),'fair_odds':float(r['fair_odds']),'book_odds':price,'ev':ev,'ev_conservative':evc,'candidate':r['candidato'].lower()=='true','sample_home':int(r['sample_home']),'sample_away':int(r['sample_away']),'captured_at':r['captured_at']})
            results.sort(key=lambda x:(not x['candidate'],-x['ev_conservative']))
            self.reply(200,{'signals':results[:2000],'count':len(results),'notice':'Estimaciones no validadas; no se garantiza valor real ni beneficios.'});return
        return super().do_GET()
    def do_POST(self):
        if urlparse(self.path).path!='/api/refresh':self.reply(404,{'error':'No encontrado'});return
        ok,msg=ENGINE.refresh(force=True)
        self.reply(202 if ok else 429,{'ok':ok,'message':msg})
    def log_message(self,fmt,*args): pass

def main():
    global ENGINE
    p=argparse.ArgumentParser(description='Radar Fútbol: aplicación móvil PWA con escaneo programado')
    p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8765)
    p.add_argument('--interval-hours',type=float,default=24)
    p.add_argument('--leagues',default='soccer_spain_la_liga,soccer_epl,soccer_italy_serie_a')
    p.add_argument('--max-leagues',type=int,default=3)
    args=p.parse_args()
    ENGINE=Engine(args.interval_hours,[v.strip() for v in args.leagues.split(',') if v.strip()],args.max_leagues)
    threading.Thread(target=ENGINE.loop,daemon=True).start()
    print(f'Radar móvil en http://{args.host}:{args.port} (requiere clave gratuita y servidor encendido)')
    ThreadingHTTPServer((args.host,args.port),Handler).serve_forever()

if __name__=='__main__':main()
